import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Using a relative base so the built app works when served from a
// GitHub Pages project subpath (e.g. https://username.github.io/paradise-nursery/).
// The app itself uses HashRouter, so no server-side rewrite rules are needed.
export default defineConfig({
  plugins: [react()],
  base: './',
});
