import echeveria from '../assets/echeveria.svg';
import barrelCactus from '../assets/barrel-cactus.svg';
import snakePlant from '../assets/snake-plant.svg';
import peaceLily from '../assets/peace-lily.svg';
import rosemary from '../assets/rosemary.svg';
import lavender from '../assets/lavender.svg';
import pothos from '../assets/pothos.svg';
import stringOfPearls from '../assets/string-of-pearls.svg';

// Each plant has a unique id, name, price (number, USD), category and thumbnail.
export const categories = [
  {
    name: 'Succulents & Cacti',
    description: 'Low-maintenance desert dwellers that thrive on neglect and sunshine.',
    plants: [
      {
        id: 'echeveria',
        name: 'Echeveria Rosette',
        price: 18,
        image: echeveria,
        description: 'A blue-green rosette succulent that loves a bright windowsill.',
      },
      {
        id: 'barrel-cactus',
        name: 'Golden Barrel Cactus',
        price: 24,
        image: barrelCactus,
        description: 'A sculptural, spine-covered globe that barely needs watering.',
      },
    ],
  },
  {
    name: 'Air-Purifying Plants',
    description: 'Leafy companions that quietly clean the air while you sleep.',
    plants: [
      {
        id: 'snake-plant',
        name: 'Snake Plant',
        price: 22,
        image: snakePlant,
        description: 'Upright, sword-like leaves that tolerate almost any light.',
      },
      {
        id: 'peace-lily',
        name: 'Peace Lily',
        price: 26,
        image: peaceLily,
        description: 'Glossy leaves and white blooms that thrive in shady corners.',
      },
    ],
  },
  {
    name: 'Aromatic Herbs',
    description: 'Fragrant plants for a kitchen windowsill or sunny balcony.',
    plants: [
      {
        id: 'rosemary',
        name: 'Rosemary',
        price: 14,
        image: rosemary,
        description: 'A woody, piney herb that rewards a sunny spot with fresh sprigs.',
      },
      {
        id: 'lavender',
        name: 'English Lavender',
        price: 16,
        image: lavender,
        description: 'Silvery foliage and violet spikes with a calming scent.',
      },
    ],
  },
  {
    name: 'Trailing & Vining',
    description: 'Cascading greenery for shelves, hooks, and hanging baskets.',
    plants: [
      {
        id: 'pothos',
        name: 'Golden Pothos',
        price: 20,
        image: pothos,
        description: 'Heart-shaped leaves on trailing vines, nearly impossible to kill.',
      },
      {
        id: 'string-of-pearls',
        name: 'String of Pearls',
        price: 19,
        image: stringOfPearls,
        description: 'Bead-like leaves that spill gracefully over the pot\u2019s edge.',
      },
    ],
  },
];

// Flat list, handy for lookups by id.
export const allPlants = categories.flatMap((category) => category.plants);
