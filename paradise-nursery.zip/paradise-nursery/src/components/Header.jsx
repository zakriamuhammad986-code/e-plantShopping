import { NavLink } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { selectTotalItems } from './CartSlice.jsx';
import './Header.css';

function CartIcon() {
  return (
    <svg
      width="26"
      height="26"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.8"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
    >
      <circle cx="9" cy="20" r="1.4" fill="currentColor" stroke="none" />
      <circle cx="18" cy="20" r="1.4" fill="currentColor" stroke="none" />
      <path d="M2.5 3h2l2.2 12.2a2 2 0 0 0 2 1.6h8.6a2 2 0 0 0 2-1.6L21 7H6" />
    </svg>
  );
}

export default function Header() {
  const totalItems = useSelector(selectTotalItems);

  return (
    <header className="site-header">
      <NavLink to="/" className="brand" end>
        Paradise Nursery
      </NavLink>
      <nav className="site-nav" aria-label="Main navigation">
        <NavLink to="/" end className={({ isActive }) => (isActive ? 'active' : '')}>
          Home
        </NavLink>
        <NavLink to="/plants" className={({ isActive }) => (isActive ? 'active' : '')}>
          Plants
        </NavLink>
        <NavLink to="/cart" className={({ isActive }) => (isActive ? 'active' : '')}>
          <span className="cart-link">
            <CartIcon />
            Cart
            <span className="cart-badge" aria-label={`${totalItems} items in cart`}>
              {totalItems}
            </span>
          </span>
        </NavLink>
      </nav>
    </header>
  );
}
